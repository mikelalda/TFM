# Dataset directory

In order to run the tests for this library, download or symlink the files of
the NYU V2 dataset here.

More specifically, the files the test code will try to load are:

- `nyu_depth_v2_labeled.mat` for the labeled subset

- At least one part of the raw dataset, as `*.zip` files
  (for example, download and place `cafe.zip` here)
